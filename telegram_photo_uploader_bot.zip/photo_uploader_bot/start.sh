#!/bin/bash
python photo_bot.py
